<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from tevratgundogdu.com/works/ideabox-html-template/author-posts-1.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Nov 2019 12:01:48 GMT -->
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Ideabox - Material Blog/Magazine Template</title>

	<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,600,700,900&amp;subset=latin-ext" rel="stylesheet">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

	<!-- Tooltip plugin (zebra) css file -->
	<link rel="stylesheet" type="text/css" href="plugins/zebra-tooltip/zebra_tooltips.min.css">

	<!-- Ideabox main theme css file. you have to add all pages -->
	<link rel="stylesheet" type="text/css" href="css/main-style.css">

	<!-- Ideabox responsive css file -->
	<link rel="stylesheet" type="text/css" href="css/responsive-style.css">
</head>

<body>
	
	<!-- header start -->
	<header class="header">
		<div class="header-wrapper">

			<!--sidebar menu toggler start -->
			<div class="toggle-sidebar material-button">
				<i class="material-icons">&#xE5D2;</i>
			</div>
			<!--sidebar menu toggler end -->

			<!--logo start -->
			<div class="logo-box">
				<h1>
					<a href="index.html" class="logo"></a>
				</h1>
			</div>
			<!--logo end -->

			<div class="header-menu">

				<!-- header left menu start -->
				<ul class="header-navigation" data-show-menu-on-mobile>
					<li>
						<a href="#" class="material-button submenu-toggle">HOME</a>
						<div class="header-submenu">
							<ul>
								<li><a href="index.html">Home demo 1</a></li>
								<li><a href="index2.html">Home demo 2</a></li>
								<li><a href="index3.html">Home demo 3</a></li>
								<li><a href="index4.html">Home demo 4</a></li>
								<li><a href="index5.html">Home demo 5</a></li>
								<li><a href="index6.html">Home demo 6</a></li>
							</ul>
						</div>
					</li>
					<li>
						<a href="#" class="material-button submenu-toggle">POSTS</a>
						<div class="header-submenu">
							<ul>
								<li><a href="list-timeline.html">List timeline</a></li>
								<li><a href="list-two-column.html">List column 2</a></li>
								<li><a href="list-three-column.html">List column 3</a></li>
								<li><a href="detail-standart.html">Detail standart</a></li>
								<li><a href="detail-parallax.html">Detail parallax</a></li>
								<li><a href="detail-with-large-adbox.html">Detail adbox 1</a></li>
								<li><a href="detail-with-slim-adbox.html">Detail adbox 2</a></li>
								<li><a href="detail-left-sidebar.html">Left sidebar</a></li>
								<li><a href="detail-left-sidebar-adbox.html">Left sidebar adbox</a></li>
								<li><a href="detail-full-width.html">Full width</a></li>								
							</ul>
						</div>
					</li>
					<li>
						<a href="#" class="material-button submenu-toggle">VIDEO</a>
						<div class="header-submenu">
							<ul>
								<li><a href="video-standart.html">Video standart</a></li>
								<li><a href="video-iframe.html">Video iframe</a></li>
								<li><a href="video-custom-player.html">Video custom player</a></li>
							</ul>
						</div>
					</li>
					<li>
						<a href="#" class="material-button submenu-toggle">EXTRA PAGES <i class="material-icons">&#xE313;</i></a>
						<div class="header-submenu">
							<ul>
								<li><a href="authors.html">Authors</a></li>
								<li><a href="author-posts-1.html">Author posts-column</a></li>
								<li><a href="author-posts-2.html">Author posts-timeline</a></li>
								<li><a href="about-us.html">About us</a></li>
								<li><a href="privacy-policy.html">Privacy policy</a></li>								
								<li><a href="contact.html">Contact</a></li>
								<li><a href="error.html">Error</a></li>
							</ul>
						</div>
					</li>
				</ul>
				<!-- header left menu end -->

			</div>
			<div class="header-right with-seperator">

				<!-- header right menu start -->
				<ul class="header-navigation">
					<li>
						<a href="#" class="material-button search-toggle"><i class="material-icons">&#xE8B6;</i></a>
					</li>
					<li>
						<a href="#" class="material-button submenu-toggle"><i class="material-icons">&#xE7FD;</i> <span class="hide-on-tablet">Account</span></a>
						<div class="header-submenu">
							<ul>
								<li><a href="#" data-modal="loginModal">Login</a></li>
								<li><a href="#" data-modal="registerModal">Register</a></li>
							</ul>
						</div>
					</li>
					<li class="hide-on-mobile"><a href="#" class="material-button" data-modal="newsletterModal"><i class="material-icons">&#xE0E1;</i></a></li>
				</ul>
				<!-- header right menu end -->

			</div>

			<!--header search panel start -->
			<div class="search-bar">
				<form class="search-form">
					<div class="search-input-wrapper">
						<input type="text" name="qq" placeholder="search something..." class="search-input">
						<button type="submit" name="search" class="search-submit"><i class="material-icons">&#xE5C8;</i></button>
					</div>
					<span class="search-close search-toggle">
						<i class="material-icons">&#xE5CD;</i>
					</span>
				</form>
			</div>
			<!--header search panel end -->

		</div>
	</header>
	<!-- header end -->


	<!-- Left sidebar menu start -->
	<div class="sidebar">
		<div class="sidebar-wrapper">

			<!-- side menu logo start -->
			<div class="sidebar-logo">
				<a href="#"></a>
				<div class="sidebar-toggle-button">
					<i class="material-icons">&#xE317;</i>
				</div>
			</div>
			<!-- side menu logo end -->

			<!-- showing on mobile screen sizes -->
			<!-- mobile menu start -->
			<div id="mobileMenu">
				<div class="sidebar-seperate"></div>
			</div>
			<!-- mobile menu end -->

			<!-- sidebar menu start -->
			<ul class="sidebar-menu">
				<li class="active">
					<a href="#" class="material-button">
						<span class="menu-icon"><i class="material-icons">&#xE88A;</i></span>
	                	<span class="menu-label">Home</span>
	                </a>
	            </li>
	            <li>
					<a href="#" class="material-button">
						<span class="menu-icon"><i class="material-icons">&#xE038;</i></span>
	                	<span class="menu-label">Videos</span>
	                </a>
	            </li>
	            <li>
					<a href="#" class="material-button">
						<span class="menu-icon"><i class="material-icons">&#xE0BF;</i></span>
	                	<span class="menu-label">Posts</span>
	                </a>
	            </li>
	            <li>
					<a href="#" class="material-button">
						<span class="menu-icon"><i class="material-icons">&#xE866;</i></span>
	                	<span class="menu-label">Contact</span>
	                </a>
	            </li>
	            <li>
					<a href="#" class="material-button">
						<span class="menu-icon"><i class="material-icons">&#xE8B0;</i></span>
	                	<span class="menu-label">Multi Menu</span>
	                	<span class="multimenu-icon"><i class="material-icons">&#xE313;</i></span>
	                </a>
	                <ul>
	                	<li>
	                		<a href="#"><span class="menu-label">Menu Level 1</span></a>
	                	</li>
	                	<li>
	                		<a href="#"><span class="menu-label">Menu Level 2</span></a>
	                	</li>
	                	<li>
	                		<a href="#"><span class="menu-label">Menu Level 3</span></a>
	                	</li>
	                </ul>
	            </li>
			</ul>
			<!-- sidebar menu end -->

			<div class="sidebar-seperate"></div>

			<!-- sidebar menu start -->
			<ul class="sidebar-menu">
				<li>
					<a href="#" class="material-button">
						<span class="menu-icon"><i class="material-icons">&#xE88A;</i></span>
	                	<span class="menu-label">Extra Menu One</span>
	                </a>
	            </li>
	            <li>
					<a href="#" class="material-button">
						<span class="menu-icon"><i class="material-icons">&#xE8B0;</i></span>
	                	<span class="menu-label">Extra Menu Two</span>
	                </a>
	            </li>
	            <li>
					<a href="#" class="material-button">
						<span class="menu-icon"><i class="material-icons">&#xE038;</i></span>
	                	<span class="menu-label">Extra Menu Three</span>
	                </a>
	            </li>
			</ul>
			<!-- sidebar menu end -->

			<div class="sidebar-seperate"></div>

			<!-- sidebar menu start -->
			<ul class="sidebar-menu">
				<li>
					<a href="#" class="facebook material-button">
	                	<span class="menu-label">Facebook</span>
	                </a>
	            </li>
	            <li>
					<a href="#" class="twitter material-button">
	                	<span class="menu-label">Twitter</span>
	                </a>
	            </li>
	            <li>
					<a href="#" class="google-plus material-button">
	                	<span class="menu-label">Google +</span>
	                </a>
	            </li>
			</ul>
			<!-- sidebar menu end -->
		</div>
	</div>
	<!-- Left sidebar menu end -->

	<!--Main container start -->
	<main class="main-container">
		<section class="main-highlight">
			
		</section>
		<section class="main-content">
			<div class="main-content-wrapper">
				<div class="content-body">

					<div class="author-wrapper">
						<div class="author-image">
							<img src="https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50" width="100" height="100">
						</div>
						<h2 class="author-name">John Doe</h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries</p>
						<div class="author-meta">
							<span>Website : </span><a href="#">www.envato.com</a>&nbsp;&nbsp;&nbsp;<span>Posts : 57</span>
						</div>
					</div>
					
					<div class="content-timeline">
						

						<div class="post-lists">

							<div class="columns column-3">
								<div class="post-list-item">
									<div class="post-top">
										<img class="post-image" src="img/news-test-images/news-img3.jpg">
										<h3 class="post-title">
											<a href="#"><span>There are many variations of passages of Lorem Ipsum available</span></a>
										</h3>
									</div>
									<div class="post-bottom">
										<div class="post-author-box">
											<span class="author-avatar"><img alt="avatar" src="https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;f=y" class="avatar" height="24" width="24"></span>
											<a href="#" class="author-name">Bill Gates</a>
											<span class="post-date">September 17, 2018</span>
										</div>
										<div class="post-meta">
											<a href="#" class="read-more">Read more <i class="material-icons">&#xE315;</i></a>
										</div>
									</div>
								</div>
							</div>

							<div class="columns column-3">
								<div class="post-list-item">
									<div class="post-top">
										<img class="post-image" src="img/news-test-images/news-img2.jpg">
										<h3 class="post-title">
											<a href="#"><span>There are many variations of passages of Lorem Ipsum available</span></a>
										</h3>
									</div>
									<div class="post-bottom">
										<div class="post-author-box">
											<span class="author-avatar"><img alt="avatar" src="https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;f=y" class="avatar" height="24" width="24"></span>
											<a href="#" class="author-name">Bill Gates</a>
											<span class="post-date">September 17, 2018</span>
										</div>
										<div class="post-meta">
											<a href="#" class="read-more">Read more <i class="material-icons">&#xE315;</i></a>
										</div>
									</div>
								</div>
							</div>

							<div class="columns column-3">
								<div class="post-list-item">
									<div class="post-top">
										<img class="post-image" src="img/news-test-images/news-img4.jpg">
										<h3 class="post-title">
											<a href="#"><span>There are many variations of passages of Lorem Ipsum available</span></a>
										</h3>
									</div>
									<div class="post-bottom">
										<div class="post-author-box">
											<span class="author-avatar"><img alt="avatar" src="https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;f=y" class="avatar" height="24" width="24"></span>
											<a href="#" class="author-name">Bill Gates</a>
											<span class="post-date">September 17, 2018</span>
										</div>
										<div class="post-meta">
											<a href="#" class="read-more">Read more <i class="material-icons">&#xE315;</i></a>
										</div>
									</div>
								</div>
							</div>

							<div class="columns column-3">
								<div class="post-list-item">
									<div class="post-top">
										<img class="post-image" src="img/news-test-images/news-img5.jpg">
										<h3 class="post-title">
											<a href="#"><span>There are many variations of passages of Lorem Ipsum available</span></a>
										</h3>
									</div>
									<div class="post-bottom">
										<div class="post-author-box">
											<span class="author-avatar"><img alt="avatar" src="https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;f=y" class="avatar" height="24" width="24"></span>
											<a href="#" class="author-name">Bill Gates</a>
											<span class="post-date">September 17, 2018</span>
										</div>
										<div class="post-meta">
											<a href="#" class="read-more">Read more <i class="material-icons">&#xE315;</i></a>
										</div>
									</div>
								</div>
							</div>

							<div class="columns column-3">
								<div class="post-list-item">
									<div class="post-top">
										<img class="post-image" src="img/news-test-images/news-img6.jpg">
										<h3 class="post-title">
											<a href="#"><span>There are many variations of passages of Lorem Ipsum available</span></a>
										</h3>
									</div>
									<div class="post-bottom">
										<div class="post-author-box">
											<span class="author-avatar"><img alt="avatar" src="https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;f=y" class="avatar" height="24" width="24"></span>
											<a href="#" class="author-name">Bill Gates</a>
											<span class="post-date">September 17, 2018</span>
										</div>
										<div class="post-meta">
											<a href="#" class="read-more">Read more <i class="material-icons">&#xE315;</i></a>
										</div>
									</div>
								</div>
							</div>

							<div class="columns column-3">
								<div class="post-list-item">
									<div class="post-top">
										<img class="post-image" src="img/news-test-images/news-img8.jpg">
										<h3 class="post-title">
											<a href="#"><span>There are many variations of passages of Lorem Ipsum available</span></a>
										</h3>
									</div>
									<div class="post-bottom">
										<div class="post-author-box">
											<span class="author-avatar"><img alt="avatar" src="https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;f=y" class="avatar" height="24" width="24"></span>
											<a href="#" class="author-name">Bill Gates</a>
											<span class="post-date">September 17, 2018</span>
										</div>
										<div class="post-meta">
											<a href="#" class="read-more">Read more <i class="material-icons">&#xE315;</i></a>
										</div>
									</div>
								</div>
							</div>

							<div class="columns column-3">
								<div class="post-list-item">
									<div class="post-top">
										<img class="post-image" src="img/news-test-images/news-img10.jpg">
										<h3 class="post-title">
											<a href="#"><span>There are many variations of passages of Lorem Ipsum available</span></a>
										</h3>
									</div>
									<div class="post-bottom">
										<div class="post-author-box">
											<span class="author-avatar"><img alt="avatar" src="https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;f=y" class="avatar" height="24" width="24"></span>
											<a href="#" class="author-name">Bill Gates</a>
											<span class="post-date">September 17, 2018</span>
										</div>
										<div class="post-meta">
											<a href="#" class="read-more">Read more <i class="material-icons">&#xE315;</i></a>
										</div>
									</div>
								</div>
							</div>

							<div class="columns column-3">
								<div class="post-list-item">
									<div class="post-top">
										<img class="post-image" src="img/news-test-images/news-img9.jpg">
										<h3 class="post-title">
											<a href="#"><span>There are many variations of passages of Lorem Ipsum available</span></a>
										</h3>
									</div>
									<div class="post-bottom">
										<div class="post-author-box">
											<span class="author-avatar"><img alt="avatar" src="https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;f=y" class="avatar" height="24" width="24"></span>
											<a href="#" class="author-name">Bill Gates</a>
											<span class="post-date">September 17, 2018</span>
										</div>
										<div class="post-meta">
											<a href="#" class="read-more">Read more <i class="material-icons">&#xE315;</i></a>
										</div>
									</div>
								</div>
							</div>

							
						</div>

						<!--Data load more button start  -->
						<div class="load-more">
							<button class="load-more-button material-button" type="button">
								<i class="material-icons">&#xE5D5;</i>
								<span>Load More</span>
							</button>
						</div>
						<!--Data load more button start  -->
					</div>

				</div>
				<div class="content-sidebar">
					<div class="sidebar_inner">

						<div class="widget-item">
							<a href="#" class="widget-ad-box">
								<img src="img/adbox300x600.png" width="300" height="600">
							</a>
						</div>

						<div class="widget-item">
							<div class="w-header">
								<div class="w-title">Editor's Picks</div>
								<div class="w-seperator"></div>
							</div>
							<div class="w-boxed-post">
								<ul>
									<li class="active">
										<a href="#" style="background-image: url(img/news-test-images/news-img7.jpg);">
											<div class="box-wrapper">
												<div class="box-left">
													<span>1</span>
												</div>
												<div class="box-right">
													<h3 class="p-title">Things to Consider When Choosing City Moving Companies</h3>
													<div class="p-icons">
														213 likes . 124 comments
													</div>
												</div>
											</div>
										</a>
									</li>
									<li>
										<a href="#" style="background-image: url(img/news-test-images/news-img5.jpg);">
											<div class="box-wrapper">
												<div class="box-left">
													<span>2</span>
												</div>
												<div class="box-right">
													<h3 class="p-title">Things to Consider When Choosing City Moving Companies</h3>
													<div class="p-icons">
														213 likes . 124 comments
													</div>
												</div>
											</div>
										</a>
									</li>
									<li>
										<a href="#" style="background-image: url(img/news-test-images/news-img6.jpg);">
											<div class="box-wrapper">
												<div class="box-left">
													<span>3</span>
												</div>
												<div class="box-right">
													<h3 class="p-title">Things to Consider When Choosing City Moving Companies</h3>
													<div class="p-icons">
														213 likes . 124 comments
													</div>
												</div>
											</div>
										</a>
									</li>
									<li>
										<a href="#" style="background-image: url(img/news-test-images/news-img3.jpg);">
											<div class="box-wrapper">
												<div class="box-left">
													<span>4</span>
												</div>
												<div class="box-right">
													<h3 class="p-title">Things to Consider When Choosing City Moving Companies</h3>
													<div class="p-icons">
														213 likes . 124 comments
													</div>
												</div>
											</div>
										</a>
									</li>
								</ul>
							</div>
						</div>

						<div class="seperator"></div>

						<a href="#" class="widget-ad-box">
							<img src="img/adbox300x250.png" width="300" height="250">
						</a>

					</div>
				</div>
			</div>
		</section>

	</main>

	<!-- Register popup html source start -->
	<div class="m-modal-box" id="registerModal">
		<div class="m-modal-overlay"></div>
		<div class="m-modal-content small">
			<div class="m-modal-header">
				<h3 class="m-modal-title">Register</h3>
				<span class="m-modal-close"><i class="material-icons">&#xE5CD;</i></span>
			</div>
			<div class="m-modal-body">
				<div class="m-modal-social-logins">
					<div class="columns column-2">
						<button class="frm-button facebook material-button full" type="button">Facebook</button>
					</div>
					<div class="columns column-2">
						<button class="frm-button twitter material-button full" type="button">Twitter</button>
					</div>
					<div class="columns column-2">
						<button class="frm-button google material-button full" type="button">Google</button>
					</div>
				</div>

				<div class="m-modal-seperator"><span>OR</span></div>

				<form>
					<div class="frm-row">
						<input class="frm-input" type="text" name="name" placeholder="Name">
					</div>
					<div class="frm-row">
						<input class="frm-input" type="text" name="username" placeholder="Username">
					</div>
					<div class="frm-row">
						<input class="frm-input" type="text" name="email" placeholder="Email">
					</div>
					<div class="frm-row">
						<input class="frm-input" type="text" name="password" placeholder="Password">
					</div>
					<div class="frm-row">
						<label class="frm-check-radio-label"><input type="checkbox" name="test"> <span>I accept your <a href="#">register policy</a>.</span></label>
					</div>
					<div class="frm-row">
						<button class="frm-button material-button full" type="button">Register</button>
					</div>
				</form>
				<div class="frm-row">
					<p class="txt-center">Do you already have an account? <a href="#" data-modal="loginModal">Login</a></p>
				</div>
			</div>
		</div>
	</div>
	<!-- Register popup html source end -->

	<!-- Login popup html source start -->
	<div class="m-modal-box" id="loginModal">
		<div class="m-modal-overlay"></div>
		<div class="m-modal-content small">
			<div class="m-modal-header">
				<h3 class="m-modal-title">Login</h3>
				<span class="m-modal-close"><i class="material-icons">&#xE5CD;</i></span>
			</div>
			<div class="m-modal-body">
				<div class="m-modal-social-logins">
					<div class="columns column-3">
						<button class="frm-button facebook material-button full" type="button">Facebook</button>
					</div>
					<div class="columns column-3">
						<button class="frm-button google material-button full" type="button">Google</button>
					</div>
				</div>

				<div class="m-modal-seperator"><span>OR</span></div>

				<form>
					<div class="frm-row">
						<input class="frm-input" type="text" name="email" placeholder="Email">
					</div>
					<div class="frm-row">
						<input class="frm-input" type="text" name="password" placeholder="Password">
					</div>
					<div class="frm-row">
						<button class="frm-button material-button full" type="button">Login</button>
					</div>
				</form>
				<div class="frm-row">
					<p class="txt-center">Don't you have an account yet? <a href="#" data-modal="registerModal">Register</a></p>
				</div>
			</div>
		</div>
	</div>
	<!-- Login popup html source end -->

	<!-- Newsletter popup html source start -->
	<div class="m-modal-box" id="newsletterModal">
		<div class="m-modal-overlay"></div>
		<div class="m-modal-content small">
			<div class="m-modal-header">
				<h3 class="m-modal-title">Newsletter</h3>
				<span class="m-modal-close"><i class="material-icons">&#xE5CD;</i></span>
			</div>
			<div class="m-modal-body">
				<p>Submit to our newsletter to receive exclusive stories delivered to you inbox!</p>
				<form>
					<div class="frm-row">
						<input class="frm-input" type="text" name="email" placeholder="Email address">
					</div>
					<div class="frm-row">
						<button class="frm-button material-button full" type="button">Send</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Newsletter popup html source end -->

	<div class="overlay"></div>

	<script src="js/jquery-3.2.1.min.js"></script>

	<!-- Tooltip plugin (zebra) js file -->
	<script src="plugins/zebra-tooltip/zebra_tooltips.min.js"></script>

	<!-- Ideabox theme js file. you have to add all pages. -->
	<script src="js/main-script.js"></script>

</body>


<!-- Mirrored from tevratgundogdu.com/works/ideabox-html-template/author-posts-1.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Nov 2019 12:01:48 GMT -->
</html>