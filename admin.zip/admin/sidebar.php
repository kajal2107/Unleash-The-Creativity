<nav class="navigation">
                    <ul class="navi-acc" id="nav2">
                        <li>
                        <a href="dashboard2.php" class="dashboard">Dashboard</a>
                    	</li>
                        <li>
                            <a href="#forms" class="forms">Manage State</a>
                            <ul>
                                <li><a href="addstate.php">Add State</a></li>
                                <li><a href="viewstate.php">View State</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#forms" class="forms">Manage City</a>
                            <ul>
                                <li><a href="addcity.php">Add city</a></li>
                                <li><a href="viewcity.php">View city</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#forms" class="forms">Manage Security Question</a>
                            <ul>
                                <li><a href="addsecurity.php">Add Question</a></li>
                                <li><a href="viewsecurity.php">View Question</a></li>
                            </ul>
                        </li>
                        
                        
                        <li>
                            <a href="#forms" class="forms">Manage User</a>
                            <ul>
                                <li><a href="adduser.php">Add User</a></li>
                                <li><a href="viewuser.php">View User</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#pages" class="pages">Manage Product Category</a>
                            <ul>
                                <li><a href="addproductcategory.php">Add Product Category</a></li>
                                <li><a href="viewproductcategory.php">View Product Category</a></li>
                            </ul>
                        </li>
                        
                        <li>
                            <a href="#pages" class="pages">Manage Category</a>
                            <ul>
                            	<li><a href="addcategory.php">Add Category</a></li>
                                <li><a href="viewcategory.php">View Category</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#pages" class="pages">Manage Sub Category</a>
                            <ul>
                            	<li><a href="addsubcategory.php">Add Sub Category</a></li>
                                <li><a href="viewsubcategory.php">View Sub Category</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>